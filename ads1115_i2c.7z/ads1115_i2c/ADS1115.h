/* registers */
#define ADS1115_CONV_REG  0x00 // Conversion Register
#define ADS1115_CONFIG_REG  0x01 // Configuration Register
#define ADS1115_LO_THRESH_REG 0x02 // Low Threshold Register
#define ADS1115_HI_THRESH_REG 0x03 // High Threshold Register

/* other */
#define ADS1115_REG_FACTOR 32768
#define ADS1115_REG_RESET_VAL 0x8583
#define ADS1115_DISABLE_ALERT   0x0003

#define ADS1115_LATCH_DISABLED  0x0000
#define ADS1115_LATCH_ENABLED   0x0004


#define ADS1115_ACT_LOW   0x0000
#define ADS1115_ACT_HIGH  0x0008


#define ADS1115_MAX_LIMIT  0x0000
#define ADS1115_WINDOW     0x0010 



#define ADS1115_8_SPS    0x0000
#define ADS1115_16_SPS   0x0020
#define ADS1115_32_SPS   0x0040
#define ADS1115_64_SPS   0x0050
#define ADS1115_128_SPS  0x0080
#define ADS1115_250_SPS  0x00A0
#define ADS1115_475_SPS  0x00C0
#define ADS1115_860_SPS  0x00E0

#define ADS1115_CONTINUOUS  0x0000 
#define ADS1115_SINGLE      0x0100


#define ADS1115_RANGE_6144   0x0000
#define ADS1115_RANGE_4096   0x0200
#define ADS1115_RANGE_2048   0x0400
#define ADS1115_RANGE_1024   0x0600
#define ADS1115_RANGE_0512   0x0800
#define ADS1115_RANGE_0256   0x0A00


#define ADS1115_COMP_0_1    0x0000
#define ADS1115_COMP_0_3    0x1000
#define ADS1115_COMP_1_3    0x2000
#define ADS1115_COMP_2_3    0x3000
#define ADS1115_COMP_0_GND  0x4000
#define ADS1115_COMP_1_GND  0x5000
#define ADS1115_COMP_2_GND  0x6000
#define ADS1115_COMP_3_GND  0x7000


#define ADS1115_BUSY           0x0000
#define ADS1115_START_ISREADY  0x8000

  /* Set the conversion rate in SPS (samples per second)
   * Options should be self-explaining:
   *
   * ADS1115_8_SPS
   * ADS1115_16_SPS
   * ADS1115_32_SPS
   * ADS1115_64_SPS
   * ADS1115_128_SPS (default)
   * ADS1115_250_SPS
   * ADS1115_475_SPS
   * ADS1115_860_SPS
   */
  void ADS1115_setConvRate(uint16_t rate);

  /* Set continuous or single shot mode:
   *
   * ADS1115_CONTINUOUS  ->  continuous mode
   * ADS1115_SINGLE     ->  single shot mode (default)
   */
  void ADS1115_setMeasureMode(uint16_t mode);

  /* Set the voltage range of the ADC to adjust the gain:
   * Please note that you must not apply more than VDD + 0.3V to the input pins!
   *
   * ADS1115_RANGE_6144  ->  +/- 6144 mV
   * ADS1115_RANGE_4096  ->  +/- 4096 mV
   * ADS1115_RANGE_2048  ->  +/- 2048 mV (default)
   * ADS1115_RANGE_1024  ->  +/- 1024 mV
   * ADS1115_RANGE_0512  ->  +/- 512 mV
   * ADS1115_RANGE_0256  ->  +/- 256 mV
   */
  void  ADS1115_setVoltageRange_mV(uint16_t range);

  /* Set the inputs to be compared
   *
   * ADS1115_COMP_0_1    ->  compares 0 with 1 (default)
   * ADS1115_COMP_0_3    ->  compares 0 with 3
   * ADS1115_COMP_1_3    ->  compares 1 with 3
   * ADS1115_COMP_2_3    ->  compares 2 with 3
   * ADS1115_COMP_0_GND  ->  compares 0 with GND
   * ADS1115_COMP_1_GND  ->  compares 1 with GND
   * ADS1115_COMP_2_GND  ->  compares 2 with GND
   * ADS1115_COMP_3_GND  ->  compares 3 with GND
  */
  void ADS1115_setCompareChannels(uint16_t mux);
  
  /* Get the raw result from the conversion register: 
   * The conversion register contains the conversion result of the amplified (!)
   * voltage. This means the value depends on the voltage as well as on the 
   * voltage range. E.g. if the voltage range is 6.144 mV (ADS1115_RANGE_6144), 
   * +32767 is 6.144 mV; if the range is 4.096 mV, +32767 is 4.096 mV, and so on.  
   */
  int16_t ADS1115_getRawResult();
  
  /* Scaling of the result to a different range: 
   * The results in the conversion register are in a range of -32767 to +32767
   * You might want to receive the result in a different scale, e.g. -1023 to 1023.
   * For -1023 to 1023, and if you have chosen e.g. ADS1115_RANGE_4096, 0 Volt would 
   * give 0 as result and 4.096 mV would give 1023. -4.096 mV would give -1023.
   */
  uint16_t voltageRange;
  int deviceMeasureMode;
  uint8_t i2cAddress;
  int16_t ADS1115_calcLimit(float rawLimit);
  uint8_t ADS1115_writeRegister(uint8_t reg, uint16_t val);
  uint16_t ADS1115_readRegister(uint8_t reg);


//######################################################################


void ADS1115_reset(){
  Wire_beginTransmission(0);
  Wire_write(0x06);
  Wire_endTransmission();
}

bool ADS1115_init(uint8_t Address){  
  i2cAddress = Address;
  Wire_beginTransmission(i2cAddress);
  uint8_t success = Wire_endTransmission();
  if(success){
    return 0;
  }
  ADS1115_writeRegister(ADS1115_CONFIG_REG, ADS1115_REG_RESET_VAL);
  ADS1115_setVoltageRange_mV(ADS1115_RANGE_2048);
  ADS1115_writeRegister(ADS1115_LO_THRESH_REG, 0x8000);
  ADS1115_writeRegister(ADS1115_HI_THRESH_REG, 0x7FFF);
  return 1;
}



void ADS1115_setConvRate(uint16_t rate){
  uint16_t currentConfReg = ADS1115_readRegister(ADS1115_CONFIG_REG);
  currentConfReg &= ~(0x00E0);  
  currentConfReg |= rate;
  ADS1115_writeRegister(ADS1115_CONFIG_REG, currentConfReg);
}
    
void ADS1115_setMeasureMode(uint16_t mode){
  uint16_t currentConfReg = ADS1115_readRegister(ADS1115_CONFIG_REG);
  currentConfReg &= ~(0x0100);  
  currentConfReg |= mode;
  ADS1115_writeRegister(ADS1115_CONFIG_REG, currentConfReg);
}

void ADS1115_setVoltageRange_mV(uint16_t range){
  uint16_t currentVoltageRange = voltageRange;
  uint16_t currentConfReg = ADS1115_readRegister(ADS1115_CONFIG_REG);
  uint16_t currentRange = (currentConfReg >> 9) & 7;
  uint16_t currentAlertPinMode = currentConfReg & 3;
  
  ADS1115_setMeasureMode(ADS1115_SINGLE);
  
  switch(range){
    case ADS1115_RANGE_6144:
      voltageRange = 6144;
      break;
    case ADS1115_RANGE_4096:
      voltageRange = 4096;
      break;
    case ADS1115_RANGE_2048:
      voltageRange = 2048;
      break;
    case ADS1115_RANGE_1024:
      voltageRange = 1024;
      break;
    case ADS1115_RANGE_0512:
      voltageRange = 512;
      break;
    case ADS1115_RANGE_0256:
      voltageRange = 256;
      break;
  }
  
  if ((currentRange != range) && (currentAlertPinMode != ADS1115_DISABLE_ALERT)){
    int16_t alertLimit = ADS1115_readRegister(ADS1115_HI_THRESH_REG);
    alertLimit = alertLimit * (currentVoltageRange * 1.0 / voltageRange);
    ADS1115_writeRegister(ADS1115_HI_THRESH_REG, alertLimit);
    
    alertLimit = ADS1115_readRegister(ADS1115_LO_THRESH_REG);
    alertLimit = alertLimit * (currentVoltageRange * 1.0 / voltageRange);
    ADS1115_writeRegister(ADS1115_LO_THRESH_REG, alertLimit);
  }
  
  currentConfReg &= ~(0x0E00);  
  currentConfReg |= range;
  ADS1115_writeRegister(ADS1115_CONFIG_REG, currentConfReg);
}

void ADS1115_setCompareChannels(uint16_t mux){
  uint16_t currentConfReg = ADS1115_readRegister(ADS1115_CONFIG_REG);
  currentConfReg &= ~(0x7000);  
  currentConfReg |= (mux);
  ADS1115_writeRegister(ADS1115_CONFIG_REG, currentConfReg);  
}


int16_t ADS1115_getRawResult(){
  int16_t rawResult = ADS1115_readRegister(ADS1115_CONV_REG);
  return rawResult;
}



int16_t ADS1115_calcLimit(float rawLimit){
  int16_t limit = (int16_t)((rawLimit * ADS1115_REG_FACTOR / voltageRange)*1000);
  return limit;
}

uint8_t ADS1115_writeRegister(uint8_t reg, uint16_t val){
  Wire_beginTransmission(i2cAddress);
  uint8_t lVal = val & 255;
  uint8_t hVal = val >> 8;
  Wire_write(reg);
  Wire_write(hVal);
  Wire_write(lVal);
  return Wire_endTransmission();
}
  
uint16_t ADS1115_readRegister(uint8_t reg){
  uint8_t MSByte = 0, LSByte = 0;
  uint16_t regValue = 0;
  Wire_beginTransmission(i2cAddress);
  Wire_write(reg);
  Wire_endTransmission();
  Wire_requestFrom(i2cAddress,2);
  if(Wire_available()){
    MSByte = Wire_read();
    LSByte = Wire_read();
  }
  regValue = (MSByte<<8) + LSByte;
  return regValue;
}
  


