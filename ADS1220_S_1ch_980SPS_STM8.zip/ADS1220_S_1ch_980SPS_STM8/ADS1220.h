//############################################################################
//STM8 version
//ADS1220 SPI commands
#define SPI_MASTER_DUMMY    0xFF
#define RESET               0x06   //Send the RESET command (06h) to make sure the ADS1220 is properly reset after power-up
#define START               0x08    //Send the START/SYNC command (08h) to start converting in continuous conversion mode
#define WREG  0x40
#define RREG  0x20

//Config registers
#define CONFIG_REG0_ADDRESS 0x00
#define CONFIG_REG1_ADDRESS 0x01
#define CONFIG_REG2_ADDRESS 0x02
#define CONFIG_REG3_ADDRESS 0x03

#define REG_CONFIG1_DR_MASK       0xE0
#define REG_CONFIG0_PGA_GAIN_MASK 0x0E
#define REG_CONFIG0_MUX_MASK      0xF0

#define DR_20SPS    0x00 
#define DR_45SPS    0x20
#define DR_90SPS    0x40
#define DR_175SPS   0x60
#define DR_330SPS   0x80
#define DR_600SPS   0xA0
#define DR_1000SPS  0xC0

#define PGA_GAIN_1   0x00
#define PGA_GAIN_2   0x02
#define PGA_GAIN_4   0x04
#define PGA_GAIN_8   0x06
#define PGA_GAIN_16  0x08
#define PGA_GAIN_32  0x0A
#define PGA_GAIN_64  0x0C
#define PGA_GAIN_128 0x0E

#define MUX_AIN0_AIN1   0x00
#define MUX_AIN0_AIN2   0x10
#define MUX_AIN0_AIN3   0x20
#define MUX_AIN1_AIN2   0x30
#define MUX_AIN1_AIN3   0x40
#define MUX_AIN2_AIN3   0x50
#define MUX_AIN1_AIN0   0x60
#define MUX_AIN3_AIN2   0x70
#define MUX_AIN0_AVSS   0x80
#define MUX_AIN1_AVSS   0x90
#define MUX_AIN2_AVSS   0xA0
#define MUX_AIN3_AVSS   0xB0

#define MUX_SE_CH0      0x80
#define MUX_SE_CH1      0x90
#define MUX_SE_CH2      0xA0
#define MUX_SE_CH3      0xB0

#define _BV(bit) (1<<(bit))

      uint8_t m_config_reg0;
      uint8_t m_config_reg1;
      uint8_t m_config_reg2;
      uint8_t m_config_reg3;

      uint8_t Config_Reg0;
      uint8_t Config_Reg1;
      uint8_t Config_Reg2;
      uint8_t Config_Reg3;

      uint8_t m_drdy_pin=0;
      uint8_t m_cs_pin=0;
      
      uint8_t NewDataAvailable;


      void ADS1220_begin(uint8_t cs_pin, uint8_t drdy_pin);
      void ADS1220_Start_Conv(void);
      void ADS1220_Reset(void);

      void ADS1220_SPI_Command(unsigned char data_in);
      void ADS1220_writeRegister(uint8_t address, uint8_t value);
      uint8_t ADS1220_readRegister(uint8_t address);
      uint8_t * ADS1220_Read_Data(void);
      int32_t ADS1220_Read_WaitForData();

      uint8_t * ADS1220_get_config_reg(void);

      void ADS1220_PGA_OFF(void);
      void ADS1220_PGA_ON(void);
      void ADS1220_set_conv_mode_continuous(void);
      void ADS1220_Single_shot_mode_ON(void);
      void ADS1220_set_data_rate(int datarate);
      void ADS1220_set_pga_gain(int pgagain);
      void ADS1220_select_mux_channels(int channels_conf);
      void ADS1220_set_conv_mode_single_shot(void);
      void ADS1220_strain_gage(); 

//############################################################################

void ADS1220_writeRegister(uint8_t address, uint8_t value)
{
    digitalWrite(m_cs_pin,LOW);
    delayMicroseconds(100);
    SPI_transfer(WREG|(address<<2));
    SPI_transfer(value);
    delayMicroseconds(100);
    digitalWrite(m_cs_pin,HIGH);
}

uint8_t ADS1220_readRegister(uint8_t address)
{
    uint8_t data;

    digitalWrite(m_cs_pin,LOW);
    delayMicroseconds(100);
    SPI_transfer(RREG|(address<<2));
    data = SPI_transfer(SPI_MASTER_DUMMY);
    delayMicroseconds(100);
    digitalWrite(m_cs_pin,HIGH);

    return data;
}

void ADS1220_strain_gage()
{
    digitalWrite(m_cs_pin,LOW);
    m_config_reg0 = 0x3E;   //Default settings: AINP=AIN1, AINN=AIN2, Gain 128, PGA enabled
    m_config_reg1 = 0x04;   //Default settings: DR=20 SPS, Mode=Normal, Conv mode=continuous, Temp Sensor disabled, Current Source off
    m_config_reg2 = 0x98;   //Reference (REFP1, REFN1), simultaneous 50-Hz and 60-Hz rejection, PSW = 1
    m_config_reg3 = 0x00;   //Default settings: IDAC1 disabled, IDAC2 disabled, DRDY pin only

    ADS1220_writeRegister( CONFIG_REG0_ADDRESS , m_config_reg0);
    ADS1220_writeRegister( CONFIG_REG1_ADDRESS , m_config_reg1);
    ADS1220_writeRegister( CONFIG_REG2_ADDRESS , m_config_reg2);
    ADS1220_writeRegister( CONFIG_REG3_ADDRESS , m_config_reg3);
    digitalWrite(m_cs_pin,HIGH);
}

void ADS1220_begin(uint8_t cs_pin, uint8_t drdy_pin)
{
    m_drdy_pin=drdy_pin;
    m_cs_pin=cs_pin;

    pinMode(m_cs_pin, OUTPUT);
    pinMode(m_drdy_pin, INPUT);

    SPI_begin();
    SPI_setBitOrder(MSBFIRST);
    SPI_setDataMode(SPI_MODE1);

    delay(100);
    ADS1220_Reset();
    delay(100);

    digitalWrite(m_cs_pin,LOW);

    m_config_reg0 = 0x00;   //Default settings: AINP=AIN0, AINN=AIN1, Gain 1, PGA enabled
    m_config_reg1 = 0x04;   //Default settings: DR=20 SPS, Mode=Normal, Conv mode=continuous, Temp Sensor disabled, Current Source off
    m_config_reg2 = 0x10;   //Default settings: Vref internal, 50/60Hz rejection, power open, IDAC off
    m_config_reg3 = 0x00;   //Default settings: IDAC1 disabled, IDAC2 disabled, DRDY pin only

    ADS1220_writeRegister( CONFIG_REG0_ADDRESS , m_config_reg0);
    ADS1220_writeRegister( CONFIG_REG1_ADDRESS , m_config_reg1);
    ADS1220_writeRegister( CONFIG_REG2_ADDRESS , m_config_reg2);
    ADS1220_writeRegister( CONFIG_REG3_ADDRESS , m_config_reg3);

    delay(10);

    Config_Reg0 = ADS1220_readRegister(CONFIG_REG0_ADDRESS);
    Config_Reg1 = ADS1220_readRegister(CONFIG_REG1_ADDRESS);
    Config_Reg2 = ADS1220_readRegister(CONFIG_REG2_ADDRESS);
    Config_Reg3 = ADS1220_readRegister(CONFIG_REG3_ADDRESS);

   //   Serial.println("Config_Reg : ");
   // Serial.println(Config_Reg0,HEX);
   //  Serial.println(Config_Reg1,HEX);
   //  Serial.println(Config_Reg2,HEX);
   //   Serial.println(Config_Reg3,HEX);
   //   Serial.println(" ");

    digitalWrite(m_cs_pin,HIGH);
    delay(10);
    //Start_Conv();
}

void ADS1220_SPI_Command(unsigned char data_in)
{
    digitalWrite(m_cs_pin, LOW);
    delayMicroseconds(100);
    digitalWrite(m_cs_pin, HIGH);
    delayMicroseconds(100);
    digitalWrite(m_cs_pin, LOW);
    delayMicroseconds(100);
    SPI_transfer(data_in);
    delayMicroseconds(100);
    digitalWrite(m_cs_pin, HIGH);
}

void ADS1220_Reset()
{
    ADS1220_SPI_Command(RESET);
}

void ADS1220_Start_Conv()
{
    ADS1220_SPI_Command(START);
}

void ADS1220_PGA_ON(void)
{
    m_config_reg0 &= ~_BV(0);
    ADS1220_writeRegister(CONFIG_REG0_ADDRESS,m_config_reg0);
}

void ADS1220_PGA_OFF(void)
{
    m_config_reg0 |= _BV(0);
    ADS1220_writeRegister(CONFIG_REG0_ADDRESS,m_config_reg0);
}

void ADS1220_set_conv_mode_continuous(void)
{
    m_config_reg1 |= _BV(2);
    ADS1220_writeRegister(CONFIG_REG1_ADDRESS,m_config_reg1);
}

void ADS1220_set_conv_mode_single_shot(void)
{
    m_config_reg1 &= ~_BV(2);
    ADS1220_writeRegister(CONFIG_REG1_ADDRESS,m_config_reg1);
}

void ADS1220_set_data_rate(int datarate)
{
    m_config_reg1 &= ~REG_CONFIG1_DR_MASK;
    m_config_reg1 |= datarate;
    ADS1220_writeRegister(CONFIG_REG1_ADDRESS,m_config_reg1);
}

void ADS1220_select_mux_channels(int channels_conf)
{
    m_config_reg0 &= ~REG_CONFIG0_MUX_MASK;
    m_config_reg0 |= channels_conf;
    ADS1220_writeRegister(CONFIG_REG0_ADDRESS,m_config_reg0);
}

void ADS1220_set_pga_gain(int pgagain)
{
    m_config_reg0 &= ~REG_CONFIG0_PGA_GAIN_MASK;
    m_config_reg0 |= pgagain ;
    ADS1220_writeRegister(CONFIG_REG0_ADDRESS,m_config_reg0);
}

uint8_t * ADS1220_get_config_reg()
{
    static uint8_t config_Buff[4];

    m_config_reg0 = ADS1220_readRegister(CONFIG_REG0_ADDRESS);
    m_config_reg1 = ADS1220_readRegister(CONFIG_REG1_ADDRESS);
    m_config_reg2 = ADS1220_readRegister(CONFIG_REG2_ADDRESS);
    m_config_reg3 = ADS1220_readRegister(CONFIG_REG3_ADDRESS);

    config_Buff[0] = m_config_reg0 ;
    config_Buff[1] = m_config_reg1 ;
    config_Buff[2] = m_config_reg2 ;
    config_Buff[3] = m_config_reg3 ;

    return config_Buff;
}

int32_t ADS1220_Read_WaitForData()
{
    static byte SPI_Buff[3];
    int32_t mResult32=0;
    long int bit24;

         digitalWrite(m_cs_pin,LOW);                         //Take CS low
         delayMicroseconds(100);
        for (int i = 0; i < 3; i++)
        {
          SPI_Buff[i] = SPI_transfer(SPI_MASTER_DUMMY);
        }
        delayMicroseconds(100);
        digitalWrite(m_cs_pin,HIGH);                  //  Clear CS to high

        bit24 = SPI_Buff[0];
        bit24 = (bit24 << 8) | SPI_Buff[1];
        bit24 = (bit24 << 8) | SPI_Buff[2];                                 // Converting 3 bytes to a 24 bit int

        bit24= ( bit24 << 8 );
        mResult32 = ( bit24 >> 8 );                      // Converting 24 bit two's complement to 32 bit two's complement

    return mResult32;
}

//############################################################################
